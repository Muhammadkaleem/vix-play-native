package com.devbytes.vixplayer.app.ui.audio

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.devbytes.vixplayer.app.R
import com.devbytes.vixplayer.app.data.repository.AudioTrack
import com.devbytes.vixplayer.app.ui.library.components.LibraryEmptyState
import com.devbytes.vixplayer.app.ui.library.components.LibrarySkeleton

/**
 * Audio tab root — Tracks / Albums / Artists / Folders / Playlists.
 *
 * The three groupings are derived in memory from one MediaStore query, so they can't
 * disagree with each other. Drilling into a group happens **in place** (same pattern as
 * `FolderBrowserScreen`) rather than through new routes.
 *
 * Playlists joined the tab set once it had a real data model behind it.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AudioLibraryScreen(
    onAudioPlayerClick: (Long) -> Unit = {},
    onPlaylistsClick: () -> Unit = {},
    onEqualizerClick: () -> Unit = {},
    onOpenPlaylist: (Long) -> Unit = {},
    viewModel: AudioLibraryViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsState()
    val tab by viewModel.tab.collectAsState()
    val openGroup by viewModel.openGroup.collectAsState()
    val playlists by viewModel.playlists.collectAsState()
    val selected by viewModel.selected.collectAsState()
    val context = LocalContext.current
    // Track awaiting a playlist choice; non-null shows the picker.
    var pendingTrack by remember { mutableStateOf<AudioTrack?>(null) }
    // True when the picker should target the whole selection rather than one track.
    var pickerForSelection by remember { mutableStateOf(false) }
    // Only shown on API 24–28, where the platform provides no confirmation of its own.
    var confirmDelete by remember { mutableStateOf(false) }
    val message by viewModel.message.collectAsState()

    // The system delete dialog reports back here; the ViewModel then re-queries.
    val deleteConsent = rememberLauncherForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult(),
    ) { result ->
        viewModel.onDeleteConsentResult(result.resultCode == android.app.Activity.RESULT_OK)
    }

    message?.let { text ->
        LaunchedEffect(text) {
            android.widget.Toast.makeText(context, text, android.widget.Toast.LENGTH_SHORT).show()
            viewModel.consumeMessage()
        }
    }

    val selectionMode = selected.isNotEmpty()
    // Whatever list is on screen — the selection and its actions operate on this.
    val visibleTracks = openGroup?.tracks
        ?: (state as? AudioLibraryUiState.Loaded)?.tracks.orEmpty()

    // Back unwinds one layer at a time: selection, then drill, then the screen.
    BackHandler(enabled = selectionMode) { viewModel.clearSelection() }
    BackHandler(enabled = !selectionMode && openGroup != null) { viewModel.closeGroup() }

    Scaffold(
        topBar = {
            if (selectionMode) {
                // Contextual bar replaces the normal one while selecting.
                TopAppBar(
                    title = { Text("${selected.size} selected") },
                    navigationIcon = {
                        IconButton(onClick = { viewModel.clearSelection() }) {
                            Icon(
                                painter = painterResource(R.drawable.ic_close),
                                contentDescription = "Clear selection",
                            )
                        }
                    },
                    actions = {
                        IconButton(onClick = { viewModel.enqueueSelection(visibleTracks) }) {
                            Icon(
                                painter = painterResource(R.drawable.ic_playlist),
                                contentDescription = "Add to queue",
                            )
                        }
                        IconButton(onClick = {
                            pickerForSelection = true
                            pendingTrack = visibleTracks.firstOrNull()
                        }) {
                            Icon(
                                painter = painterResource(R.drawable.ic_add),
                                contentDescription = "Add to playlist",
                            )
                        }
                        IconButton(onClick = {
                            shareTracks(context, viewModel.selectedTracks(visibleTracks))
                            viewModel.clearSelection()
                        }) {
                            Icon(
                                painter = painterResource(R.drawable.ic_share),
                                contentDescription = "Share",
                            )
                        }
                        IconButton(onClick = {
                            if (viewModel.systemConfirmsDelete) {
                                // The OS shows its own dialog; a second one would just
                                // train people to dismiss without reading.
                                viewModel.deleteSelection(visibleTracks) { sender ->
                                    deleteConsent.launch(
                                        androidx.activity.result.IntentSenderRequest
                                            .Builder(sender).build()
                                    )
                                }
                            } else {
                                confirmDelete = true
                            }
                        }) {
                            Icon(
                                painter = painterResource(R.drawable.ic_delete),
                                // Says what this device will actually do: trash is
                                // recoverable, the pre-API-30 fallback is not.
                                contentDescription = if (viewModel.deleteIsRecoverable) {
                                    "Move to trash"
                                } else {
                                    "Delete"
                                },
                            )
                        }
                        IconButton(onClick = { viewModel.selectAll(visibleTracks) }) {
                            Icon(
                                painter = painterResource(R.drawable.ic_check),
                                contentDescription = "Select all",
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant,
                    ),
                )
            } else {
                TopAppBar(
                    title = { Text(openGroup?.name ?: "Audio") },
                    navigationIcon = {
                        if (openGroup != null) {
                            IconButton(onClick = { viewModel.closeGroup() }) {
                                Icon(
                                    painter = painterResource(R.drawable.ic_back),
                                    contentDescription = "Back",
                                )
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.background,
                    ),
                )
            }
        },
    ) { padding ->
        Column(modifier = Modifier.padding(padding)) {
            // Tabs stay hidden while drilled in — the title and back arrow own that level.
            if (openGroup == null) {
                ScrollableTabRow(
                    selectedTabIndex = tab.ordinal,
                    containerColor = MaterialTheme.colorScheme.background,
                    edgePadding = 12.dp,
                ) {
                    AudioTab.entries.forEach { entry ->
                        Tab(
                            selected = entry == tab,
                            onClick = { viewModel.selectTab(entry) },
                            text = { Text(entry.label) },
                        )
                    }
                }
            }

            when (val s = state) {
                is AudioLibraryUiState.Loading -> LibrarySkeleton(columns = 1)

                is AudioLibraryUiState.Empty -> LibraryEmptyState(
                    iconRes = R.drawable.ic_nav_audio,
                    title = "No music yet",
                    body = "Audio files on this device will show up here.",
                )

                is AudioLibraryUiState.Loaded -> {
                    val drilled = openGroup
                    when {
                        // Inside a group: its tracks, queued as their own context.
                        drilled != null -> TrackList(
                            tracks = drilled.tracks,
                            selected = selected,
                            selectionMode = selectionMode,
                            onPlay = { track ->
                                viewModel.play(track, drilled.tracks)
                                onAudioPlayerClick(track.mediaStoreId)
                            },
                            onToggle = { viewModel.toggleSelection(it) },
                            onAddToPlaylist = { pendingTrack = it },
                        )
                        // Tracks tab: the whole library is the context.
                        tab == AudioTab.TRACKS -> TrackList(
                            tracks = s.tracks,
                            selected = selected,
                            selectionMode = selectionMode,
                            onPlay = { track ->
                                viewModel.play(track, s.tracks)
                                onAudioPlayerClick(track.mediaStoreId)
                            },
                            onToggle = { viewModel.toggleSelection(it) },
                            onAddToPlaylist = { pendingTrack = it },
                        )

                        tab == AudioTab.PLAYLISTS -> {
                            if (playlists.isEmpty()) {
                                LibraryEmptyState(
                                    iconRes = R.drawable.ic_playlist,
                                    title = "No playlists yet",
                                    body = "Use the menu on any track to start one.",
                                )
                            } else {
                                LazyColumn {
                                    items(playlists, key = { it.id }) { playlist ->
                                        GroupRow(
                                            group = AudioGroup(
                                                name = playlist.name,
                                                trackCount = 0,
                                                artUri = "",
                                                tracks = emptyList(),
                                            ),
                                            showCount = false,
                                            onClick = { onOpenPlaylist(playlist.id) },
                                        )
                                    }
                                }
                            }
                        }

                        else -> {
                            val groups = viewModel.groupsFor(tab, s.tracks)
                            LazyColumn {
                                items(groups, key = { it.name }) { group ->
                                    GroupRow(
                                        group = group,
                                        onClick = { viewModel.openGroup(group) },
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Only reached on API 24–28: there is no system confirmation on that path, so this
    // dialog is the sole thing standing between a tap and permanent deletion.
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            // Only reachable below API 30, where there is no trash — so the wording is
            // unambiguous about permanence rather than softened.
            title = { Text("Delete ${selected.size} files?") },
            text = {
                Text("This permanently removes them from this device. It can't be undone.")
            },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    viewModel.deleteSelection(visibleTracks) { sender ->
                        deleteConsent.launch(
                            androidx.activity.result.IntentSenderRequest.Builder(sender).build()
                        )
                    }
                }) { Text("Delete") }
            },
            dismissButton = {
                TextButton(onClick = { confirmDelete = false }) { Text("Cancel") }
            },
        )
    }

    // Playlist picker for the pending track, with an inline "new playlist" path so the
    // first playlist can be created without leaving the library.
    pendingTrack?.let { track ->
        var newName by remember { mutableStateOf("") }
        var creating by remember { mutableStateOf(false) }
        AlertDialog(
            onDismissRequest = { pendingTrack = null; pickerForSelection = false },
            title = {
                Text(
                    if (pickerForSelection) {
                        "Add ${selected.size} tracks to playlist"
                    } else {
                        "Add to playlist"
                    }
                )
            },
            text = {
                Column {
                    if (creating) {
                        OutlinedTextField(
                            value = newName,
                            onValueChange = { newName = it },
                            singleLine = true,
                            label = { Text("Playlist name") },
                        )
                    } else {
                        if (playlists.isEmpty()) {
                            Text(
                                text = "No playlists yet.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        playlists.forEach { playlist ->
                            Text(
                                text = playlist.name,
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        if (pickerForSelection) {
                                            viewModel.addSelectionToPlaylist(
                                                playlist.id, visibleTracks,
                                            )
                                        } else {
                                            viewModel.addToPlaylist(playlist.id, track)
                                        }
                                        pendingTrack = null
                                        pickerForSelection = false
                                    }
                                    .padding(vertical = 12.dp),
                            )
                        }
                    }
                }
            },
            confirmButton = {
                if (creating) {
                    TextButton(
                        onClick = {
                            if (pickerForSelection) {
                                viewModel.createPlaylistWithSelection(newName, visibleTracks)
                            } else {
                                viewModel.createPlaylistWith(newName, track)
                            }
                            pendingTrack = null
                            pickerForSelection = false
                        },
                        enabled = newName.isNotBlank(),
                    ) { Text("Create") }
                } else {
                    TextButton(onClick = { creating = true }) { Text("New playlist") }
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    pendingTrack = null
                    pickerForSelection = false
                }) { Text("Cancel") }
            },
        )
    }
}

@Composable
private fun TrackList(
    tracks: List<AudioTrack>,
    selected: Set<Long>,
    selectionMode: Boolean,
    onPlay: (AudioTrack) -> Unit,
    onToggle: (AudioTrack) -> Unit,
    onAddToPlaylist: (AudioTrack) -> Unit,
) {
    LazyColumn {
        items(tracks, key = { it.mediaStoreId }) { track ->
            TrackRow(
                title = track.title,
                artist = track.artist,
                durationMs = track.durationMs,
                albumArtUri = track.albumArtUri.toString(),
                isSelected = track.mediaStoreId in selected,
                selectionMode = selectionMode,
                // In selection mode a tap toggles rather than plays.
                onClick = { if (selectionMode) onToggle(track) else onPlay(track) },
                onLongClick = { onToggle(track) },
                onAddToPlaylist = { onAddToPlaylist(track) },
            )
        }
    }
}

@Composable
private fun GroupRow(
    group: AudioGroup,
    onClick: () -> Unit,
    showCount: Boolean = true,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        AlbumArt(uri = group.artUri, size = 48.dp)
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = group.name,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            if (showCount) {
                Text(
                    text = if (group.trackCount == 1) "1 track" else "${group.trackCount} tracks",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
@OptIn(ExperimentalFoundationApi::class)
private fun TrackRow(
    title: String,
    artist: String,
    durationMs: Long,
    albumArtUri: String,
    isSelected: Boolean,
    selectionMode: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onAddToPlaylist: () -> Unit,
) {
    var menu by remember { mutableStateOf(false) }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                if (isSelected) {
                    MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)
                } else {
                    MaterialTheme.colorScheme.background
                }
            )
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        AlbumArt(uri = albumArtUri, size = 48.dp)
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = artist,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Spacer(Modifier.width(12.dp))
        Text(
            text = formatTrackDuration(durationMs),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        if (selectionMode) {
            // The overflow would be redundant while the contextual bar owns the actions.
            // Unselected rows show *nothing* rather than an ✕: a cross reads as "remove",
            // which is the opposite of "not selected". The space is reserved so rows
            // don't shift as the selection changes.
            if (isSelected) {
                Icon(
                    painter = painterResource(R.drawable.ic_check),
                    contentDescription = "Selected",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier
                        .padding(start = 8.dp)
                        .size(24.dp),
                )
            } else {
                Spacer(Modifier.padding(start = 8.dp).size(24.dp))
            }
        } else {
            Box {
                IconButton(onClick = { menu = true }) {
                    Icon(
                        painter = painterResource(R.drawable.ic_more_vert),
                        contentDescription = "More",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(
                        text = { Text("Add to playlist") },
                        onClick = { menu = false; onAddToPlaylist() },
                    )
                }
            }
        }
    }
}

/**
 * Album art from the MediaStore album-art URI. A tinted note icon sits behind it as the
 * fallback for albums with no art — the PRD's "missing art → fallback art" — so a failed
 * or empty load leaves the placeholder visible rather than a blank square.
 */
@Composable
fun AlbumArt(
    uri: String,
    size: Dp,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    Box(
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(6.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            painter = painterResource(R.drawable.ic_nav_audio),
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(size / 2),
        )
        AsyncImage(
            model = ImageRequest.Builder(context).data(uri).build(),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.size(size),
        )
    }
}

internal fun formatTrackDuration(ms: Long): String {
    val totalSec = ms / 1000
    val m = totalSec / 60
    val s = totalSec % 60
    return "$m:${s.toString().padStart(2, '0')}"
}


/**
 * Shares the given tracks via the system chooser. MediaStore content URIs are shareable
 * directly; the read grant lets the receiving app open them.
 */
private fun shareTracks(context: android.content.Context, tracks: List<AudioTrack>) {
    if (tracks.isEmpty()) return
    val uris = ArrayList(tracks.map { it.uri })
    val intent = if (uris.size == 1) {
        android.content.Intent(android.content.Intent.ACTION_SEND).apply {
            type = "audio/*"
            putExtra(android.content.Intent.EXTRA_STREAM, uris.first())
        }
    } else {
        android.content.Intent(android.content.Intent.ACTION_SEND_MULTIPLE).apply {
            type = "audio/*"
            putParcelableArrayListExtra(android.content.Intent.EXTRA_STREAM, uris)
        }
    }
    intent.addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
    // The chooser is the confirmation step: the user picks the destination.
    context.startActivity(android.content.Intent.createChooser(intent, "Share"))
}
